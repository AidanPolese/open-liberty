package com.ibm.ws.anno.test.data.uses.repeatable;

import com.ibm.ws.anno.test.data.repeatable.Author;

@Author(name = "John")
@Author(name = "George")
public class Book {

}
