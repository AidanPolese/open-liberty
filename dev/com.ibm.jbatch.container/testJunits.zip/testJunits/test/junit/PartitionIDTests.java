package test.junit;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.batch.api.partition.AbstractPartitionAnalyzer;
import javax.batch.operations.JobOperator;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.BatchStatus;
import javax.batch.runtime.JobExecution;
import javax.batch.runtime.JobInstance;
import javax.batch.runtime.StepExecution;

import org.junit.BeforeClass;
import org.junit.Test;

public class PartitionIDTests extends AbstractPartitionAnalyzer{
	
	static JobOperator jobOp = null;
	int normalSleepTime = 1200;
	
	@BeforeClass
	public static void setup(){
		jobOp = BatchRuntime.getJobOperator();
	}
	
	@Test
	public void testJobExecId() throws Exception {
		long exec1Id = jobOp.start("partitionTest", null); //always succeeds
		Thread.sleep(normalSleepTime);
		JobExecution je = jobOp.getJobExecution(exec1Id);
		String status = je.getExitStatus();
		//parse out IDs from exit strings
		String[] statusIDs = status.split(":");
		String[] jobIDs = new String[statusIDs.length - 1];
		for(int i = 1; i < statusIDs.length; i++){//before the first ":" is unimportant
			jobIDs[i - 1] = statusIDs[i].substring(statusIDs[i].indexOf("J") + 1, statusIDs[i].indexOf("I"));
		}
		
		assertEquals("batch status", BatchStatus.COMPLETED,je.getBatchStatus());
		
		int counter = 0;
		for(String j : jobIDs){
			assertEquals("Job execution " + counter++, exec1Id, Long.parseLong(j));
		}
	}
	
	@Test
	public void testJobInstanceId() throws Exception {
		long exec1Id = jobOp.start("partitionTest", null); //always succeeds
		Thread.sleep(normalSleepTime);
		JobInstance ji = jobOp.getJobInstance(exec1Id);
		long instance1Id = ji.getInstanceId();
		JobExecution je = jobOp.getJobExecution(exec1Id);
		String status = je.getExitStatus();
		//parse out IDs from exit strings
		String[] statusIDs = status.split(":");
		String[] jobIDs = new String[statusIDs.length - 1];
		for(int i = 1; i < statusIDs.length; i++){//before the first ":" is unimportant
			jobIDs[i - 1] = statusIDs[i].substring(statusIDs[i].indexOf("I") + 1, statusIDs[i].indexOf("S"));
		}
		
		assertEquals("batch status", BatchStatus.COMPLETED, je.getBatchStatus());
		int counter = 0;
		for(String j : jobIDs){
			assertEquals("Job instance " + counter++,  instance1Id, Long.parseLong(j));
		}
	}
	
	//ignore me for now
	@Test
	public void testStepExecId() throws Exception {
		long exec1Id = jobOp.start("partitionTest", null); //always succeeds
		Thread.sleep(normalSleepTime);
		JobExecution je = jobOp.getJobExecution(exec1Id);
		String status = je.getExitStatus();

		List<StepExecution> se = jobOp.getStepExecutions(exec1Id);
		assertEquals("Step exec length", se.size(), 1);
		long stepExecId = se.get(0).getStepExecutionId();

		assertEquals("batch status", BatchStatus.COMPLETED, je.getBatchStatus());

		//parse out IDs from exit strings
		String[] statusIDs = status.split(":");
		String[] stepIDs = new String[statusIDs.length - 1];
		for(int i = 1; i < statusIDs.length; i++){//before the first ":" is unimportant
			stepIDs[i - 1] = statusIDs[i].substring(statusIDs[i].indexOf("S") + 1);
		}
		
		for(String stepId : stepIDs ){
			assertEquals("Step exec ", stepExecId, Long.parseLong(stepId));
		}
	}
}
