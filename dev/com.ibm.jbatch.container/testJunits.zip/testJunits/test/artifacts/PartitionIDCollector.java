package test.artifacts;

import javax.batch.api.partition.PartitionCollector;
import javax.batch.runtime.context.JobContext;
import javax.batch.runtime.context.StepContext;
import javax.inject.Inject;

public class PartitionIDCollector implements PartitionCollector {

	@Inject
	JobContext jobCtx;
	@Inject
	StepContext stepCtx;

	@Override
	public String collectPartitionData() throws Exception {
		long jobid = jobCtx.getExecutionId();
		long instanceid = jobCtx.getInstanceId();
		long stepid = stepCtx.getStepExecutionId();
		
		String collectorData = ":J" + jobid + "I" + instanceid + "S" + stepid;
		return collectorData;
	}

}
