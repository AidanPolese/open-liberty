package test.artifacts;

import java.io.Serializable;

import javax.batch.api.partition.AbstractPartitionAnalyzer;
import javax.batch.runtime.BatchStatus;
import javax.batch.runtime.context.JobContext;
import javax.batch.runtime.context.StepContext;
import javax.inject.Inject;

public class PartitionIDAnalyzer extends AbstractPartitionAnalyzer {

	@Inject
	JobContext jobCtx;

	@Override
	public void analyzeCollectorData(Serializable data) throws Exception {
		// TODO Auto-generated method stub
		jobCtx.setExitStatus(jobCtx.getExitStatus() + data);
	}
	
}
